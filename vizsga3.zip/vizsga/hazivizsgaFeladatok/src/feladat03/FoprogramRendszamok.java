package feladat03;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class FoprogramRendszamok {

	static Scanner sc = new Scanner(System.in);
	
	public static void main(String[] args) {
		
		Set<String> rendszamok = new HashSet<String>();
		
		
		String menupont = null;
		do {
			
			System.out.println("Válasszon menüpontot:");
			System.out.println("1. Adatfelvitel");
			System.out.println("2. Behajtás ellenőrzés");
			System.out.println("3. Kilépés");
			menupont = sc.nextLine();
			
			switch (menupont) {
			
			case "1":
				
				System.out.println(adatfelvitel(rendszamok)+" új rendszámot vitt fel a rendszerbe");				
				break;
				
			case "2":
				System.out.print("Adja meg a behajtani óhajtó autó rendszámát: ");
				String rendszam = sc.nextLine();
				if (behajthat(rendszamok,rendszam)) {
					
					System.out.println("Az autó behajthat a parkolóba!");
					
				}
				else {
					
					System.out.println("Az autó nem hajthat be a parkolóba!");

				}
				break;
				
			}
			
			
		}while(!menupont.equals("3"));
		
		// TODO Ide kerüljön  a statisztika kiíratása
		
		public class Feladat03 {
		    private Set<String> rendszamok = new HashSet<>();
		    private int felvittRendszamokSzama = 0;
		    private int behajthatokSzama = 0;

		    public int adatFelvitel() {
		        Scanner scanner = new Scanner(System.in);

		        while (true) {
		            System.out.print("Kérlek, add meg a rendszámot (VÉGE a kilépéshez): ");
		            String rendszam = scanner.nextLine();

		            if (rendszam.equalsIgnoreCase("VÉGE")) {
		                break;
		            }

		            if (!rendszamok.contains(rendszam)) {
		                rendszamok.add(rendszam);
		                felvittRendszamokSzama++;
		            } else {
		                System.out.println("Ez a rendszám már szerepel a rendszerben.");
		            }
		        }

		        return felvittRendszamokSzama;
		    }

		    public void behajtasStatisztika() {
		        Scanner scanner = new Scanner(System.in);

		        while (true) {
		            System.out.print("Kérlek, add meg a behajtó rendszámot (VÉGE a kilépéshez): ");
		            String rendszam = scanner.nextLine();

		            if (rendszam.equalsIgnoreCase("VÉGE")) {
		                break;
		            }

		            if (rendszamok.contains(rendszam)) {
		                behajthatokSzama++;
		            }
		        }

		        System.out.println("Statisztika:");
		        System.out.println("Felvitt rendszámok száma: " + felvittRendszamokSzama);
		        System.out.println("Behajtható rendszámok száma: " + behajthatokSzama);
		        System.out.println("Nem behajtható rendszámok száma: " + (felvittRendszamokSzama - behajthatokSzama));
		    }
		}

	}



	private static int adatfelvitel(Set<String> rendszamok) {
		
		int ujRendszamokDarabszam = 0;
		
		// TODO Ide kerüljön adatfelvitel megvalósítása, feladatkiírásnak megfelelően
		
		public class Feladat03 {
		    private Set<String> rendszamok = new HashSet<>();

		    public int adatFelvitel() {
		        Scanner scanner = new Scanner(System.in);
		        int ujRendszamokSzama = 0;

		        while (true) {
		            System.out.print("Kérlek, add meg a rendszámot (VÉGE a kilépéshez): ");
		            String rendszam = scanner.nextLine();

		            if (rendszam.equalsIgnoreCase("VÉGE")) {
		                break;
		            }

		            if (!rendszamok.contains(rendszam)) {
		                rendszamok.add(rendszam);
		                ujRendszamokSzama++;
		            } else {
		                System.out.println("Ez a rendszám már szerepel a rendszerben.");
		            }
		        }

		        return ujRendszamokSzama;
		    }
		}
		
		return ujRendszamokDarabszam;
		
	}



	public static boolean behajthat(Set<String> rendszamok, String rendszam) {
						
		return false;			
		
	}

}

package feladat03Teszt;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import feladat03.Feladat03;

class Feladat03Teszt {

    @Test
    void behajthatTeszt() {
        // Teszteljük a behajthat metódust
        Feladat03 f03 = new Feladat03();
        f03.adatFelvitel(); // Adatokat viszünk be

        // Ellenőrizzük, hogy egy behajtható rendszám valóban behajtható
        assertTrue(f03.behajthat("ABC-123"));

        // Ellenőrizzük, hogy egy nem behajtható rendszám nem behajtható
        assertFalse(f03.behajthat("XYZ-789"));
    }
}
