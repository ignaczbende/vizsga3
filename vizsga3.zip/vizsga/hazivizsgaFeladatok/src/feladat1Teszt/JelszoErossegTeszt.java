package feladat1Teszt;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import feladat01.JelszoErosseg;

class JelszoErossegTeszt {

	@Test
	void ellenorzesTest() {
		
		String jelszo = "Jojelszo45";
		assertTrue(JelszoErosseg.ellenorzes(jelszo));
		
		public class JelszoErosseg {
			public static boolean ellenorzes(String jelszo) {
				

				if (jelszo.length() != 10) {
					return false;
				}
		
				
				if (!Character.isUpperCase(jelszo.charAt(0))) {
					return false;
				}
		
				

				for (int i = 1; i <= 8; i++) {
					if (!Character.isLowerCase(jelszo.charAt(i))) {
						return false;
					}
				}
		
				
				if (!Character.isDigit(jelszo.charAt(9)) || !Character.isDigit(jelszo.charAt(8))) {
					return false;
				}
		
				return true;
			}
		}
	}
	

}
