package feladat02;

public class Edesseg {
	
	private String megnevezes;
	private int egysegar;
	private int darabszam;

	
	
	public Edesseg(String megnevezes, int egysegar, int darabszam) {
		super();
		this.megnevezes = megnevezes;
		this.egysegar = egysegar;
		this.darabszam = darabszam;
	}



	public int keszletErtek() {
		
		return darabszam ;
				
	}
	
	public class Csokolade extends Edesseg {
	    private double kakaotartalom;

	    public Csokolade(String megnevezes, double egysegar, int darabszam, double kakaotartalom) {
	        super(megnevezes, egysegar, darabszam);
	        this.kakaotartalom = kakaotartalom;
	    }

	    public double getKakaotartalom() {
	        return kakaotartalom;
	    }

	    
	    public String toString() {
	        return super.toString() + ", Kakaótartalom: " + kakaotartalom;
	    }
	}

	public class Cukorka extends Edesseg {
	    private boolean toltott;

	    public Cukorka(String megnevezes, double egysegar, int darabszam, boolean toltott) {
	        super(megnevezes, egysegar, darabszam);
	        this.toltott = toltott;
	    }

	    public boolean isToltott() {
	        return toltott;
	    }

	   
	    public String toString() {
	        return super.toString() + ", Töltött: " + (toltott ? "Igen" : "Nem");
	    }
	}

	
}
