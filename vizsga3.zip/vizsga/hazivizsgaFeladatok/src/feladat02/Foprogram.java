package feladat02;

public class Foprogram {

	public static void main(String[] args) {
		
		// ide kerüljön a tömb feltöltése majd a kiíratás:
		public class Main {
		    public static void main(String[] args) {
		    	
		        Edesseg[] termekek = new Edesseg[3];
		        

		        termekek[0] = new Edesseg("Sütemény", 2.5, 10);
		        termekek[1] = new Csokolade("Kakaós csoki", 3.0, 5, 70.0);
		        termekek[2] = new Cukorka("Mézes cukorka", 1.0, 20, true);
		        

		        kiirTermekAdatai(termekek);
		    }
		    

		    public static void kiirTermekAdatai(Edesseg[] termekek) {
		        for (Edesseg termek : termekek) {
		            System.out.println(termek.toString() + ", Készletérték: " + termek.getKeszletErtek() + ", Típus: " + termek.getClass().getSimpleName());
		        }
		    }
		}

		public class CsokoladeTest {

		    @Test
		    void toStringTest() {
		        Csokolade csoki = new Csokolade("Kakaós csoki", 3.0, 5, 70.0);
		        String expected = "Megnevezes: Kakaós csoki, Egysegar: 3.0, Darabszam: 5, Kakaótartalom: 70.0";
		        String actual = csoki.toString();
		        
		        assertEquals(expected, actual);
		    }
		}


	}

}
