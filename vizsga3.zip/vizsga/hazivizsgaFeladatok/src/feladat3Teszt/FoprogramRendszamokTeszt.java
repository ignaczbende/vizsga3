package feladat3Teszt;

import static org.junit.jupiter.api.Assertions.*;

import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.Test;

import feladat03.FoprogramRendszamok;

class FoprogramRendszamokTeszt {

	@Test
	void behajthatTeszt() {
		
		Set<String> rendszamok = new HashSet<String>();
		rendszamok.add("ABC-123");
		rendszamok.add("DEF-456");
		
		assertTrue(FoprogramRendszamok.behajthat(rendszamok, "ABC-123"));
		
	}

}
public class FoprogramRendszamok {
    public static boolean behajthat(Set<String> rendszamok, String rendszam) {
        return rendszamok.contains(rendszam);
    }
}