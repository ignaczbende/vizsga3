package feladat04;

public class Rendeles {

	private String szallitoiAzonosito;
	private String megnevezes;
	private int mennyiseg;
	private int osszertek;
	private boolean surgos;
	


	public Rendeles(String[] csvSor) {
				
			
	}

	
}
