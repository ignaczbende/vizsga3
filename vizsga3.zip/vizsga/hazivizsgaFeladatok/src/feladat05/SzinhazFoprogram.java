package feladat05;

public class SzinhazFoprogram {

	public static void main(String[] args) {
		
		EloadasokFrame foAblak = new EloadasokFrame();
		foAblak.getFrmEloadasok().setVisible(true);

	}

}
